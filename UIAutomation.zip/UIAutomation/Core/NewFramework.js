"use strict";
exports.__esModule = true;
exports.perform = void 0;
var perform;
(function (perform) {
    perform["Click"] = "#click";
    perform["GetText"] = "#gettext";
})(perform = exports.perform || (exports.perform = {}));
// export class objr {
//     homesceen: { xpath: string; };
//     constructor(){
//         this.homesceen ={ xpath: "123"}
//         "".add(1);
//     }
//     static home(){
//         return {
//             "homesceen":{ xpath: "123"}
//         }
//     }
// }
// declare global {
//     interface String {
//         add(length : number) : string;
//     }
// }
// interface String {
//     add(...strings: string[]): string;
//   }
//   String.prototype.add = function (...strings) {
//     return this + strings.join('');
//   };
